#
# $Id: a26517cc7b6a673ce1985c8c75fba88492e1e820 $
#
# Copyright (c) 1999-2006 Minero Aoki
#
# This program is free software.
# You can distribute/modify this program under the terms of
# the GNU LGPL, Lesser General Public License version 2.1.
# For details of the GNU LGPL, see the file "COPYING".
#

module Racc
  class Error < StandardError; end
  class CompileError < Error; end
end
