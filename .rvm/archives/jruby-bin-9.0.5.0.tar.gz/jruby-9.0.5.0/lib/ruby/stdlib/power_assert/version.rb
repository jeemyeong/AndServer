module PowerAssert
  VERSION = "0.2.3"
end
