# All FFI::Pointer functionality is implemented in java
