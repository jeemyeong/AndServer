module Jars
  VERSION = '0.2.3'.freeze
  JRUBY_PLUGINS_VERSION = '1.1.2'.freeze
  DEPENDENCY_PLUGIN_VERSION = '2.8'.freeze
end
