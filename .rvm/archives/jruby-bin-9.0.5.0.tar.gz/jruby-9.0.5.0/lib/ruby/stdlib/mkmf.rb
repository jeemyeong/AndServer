raise NotImplementedError, "C extensions are not supported"
